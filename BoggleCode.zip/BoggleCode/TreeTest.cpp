#include "boggleutil.h"
#include <stdlib.h>
#include <iostream>
#include <string>

int main()
{
   std::vector<RadNode*> nodes;
   /**LexTree tree(" ");

   RadNode* root = tree.getRoot();

   tree.addChild(0, 'b', root);

   tree.addChild(1, 'c', root);
   tree.addChild(2, 'd', root);

   std::vector<RadNode*> children = root->getChildren();

   tree.addChild(0, 'e', children[0]);
   tree.addChild(1, 'f', children[0]);
   tree.addChild(2, 'g', children[0]);
   
   tree.addChild(0, 'h', children[1]);
   tree.addChild(1, 'i', children[1]);
   tree.addChild(2, 'j', children[1]);

   tree.addChild(0, 'k', children[2]);
   tree.addChild(1, 'l', children[2]);
   tree.addChild(2, 'm', children[2]);

   nodes = tree.BFS();

   for(int i = 0; i < nodes.size(); i++)
   {
      std::cout << nodes[i]->getKey() << std::endl;
   }**/

   std::string str = "abcdefghijklmnopqrstuvwxyz";

   std::cout << "str.substr(0, 1): " << str.substr(0, 1) << std::endl;

   for(int i = 0; i < str.size(); i++)
   {
      str[i] = std::toupper(str[i]);
      std::cout << str[i];
   }
   std::cout << std::endl;

   LexTree tree2;

   tree2.addWord("Cake");
   tree2.addWord("Fake");
   tree2.addWord("Lake");
   tree2.addWord("Cans");

   nodes = tree2.BFS();

   std::cout << "Size of Vector:" << nodes.size() << std::endl;
   for(int i = 0; i < nodes.size(); i++)
   {
      std::cout << nodes[i]->getKey() << " " << nodes[i]->getEnd() << std::endl;
   }

   std::cout << tree2.Search("Cake") << std::endl;
   std::cout << tree2.Search("Rake") << std::endl;
   std::cout << tree2.Search("CS") << std::endl;
   std::cout << tree2.Search("Lake") << std::endl;

   return 0;
}
