#include "boggleutil.h"
#include <stdlib.h>
#include <iostream>
#include <string>

int main()
{
   std::string** bogboard;
   std::vector<bool> visited(16, 0);

   bogboard = new std::string*[4];
 
   for(int i = 0; i < 4; i++)
   {
      bogboard[i] = new std::string[4];
   }

   bogboard[0][0] = "a";
   bogboard[0][1] = "b";
   bogboard[0][2] = "c";
   bogboard[0][3] = "d";
   bogboard[1][0] = "e";
   bogboard[1][1] = "f";
   bogboard[1][2] = "g";
   bogboard[1][3] = "h";
   bogboard[2][0] = "i";
   bogboard[2][1] = "j";
   bogboard[2][2] = "k";
   bogboard[2][3] = "l";
   bogboard[3][0] = "m";
   bogboard[3][1] = "n";
   bogboard[3][2] = "o";
   bogboard[3][3] = "p";

   for(int i = 0; i < 4; i++)
   {
      for(int j = 0; j < 4; j++)
      {
         std::cout << bogboard[i][j] << " ";
      }
      std::cout << std::endl;
   }

   Board boggle(bogboard, 4, 4);

   /**for(int i = 0; i < 4; i++)
   {
      for(int j = 0; j < 4; j++)
      {
         std::vector<int> coords = boggle.getNeighbors(i*4+ j, visited);
         std::cout << j << ", " << i << std::endl;
         for(int k = 0; k < coords.size(); k++)
         {
            std::cout << "X:" << (coords[k]%4) << " ";
            std::cout << "Y:" << (coords[k]/4) << std::endl;
         }
     
         std::cout << "________________" << std::endl;
         coords.clear();
      }
      std::cout << std::endl;
   }**/

   std::vector <int> path;
   std::vector <int> output;
   output = boggle.Check("abcde", "a", 0, visited, path);

   for(int i = 0; i < output.size(); i++)
   {
      std::cout << (output[i]/4) << ", " << (output[i]%4) << std::endl;
   }

   std::cout << "Matches(Caketime, Cake): " << boggle.matches("Caketime", "Cake") << std::endl;
   std::cout << "Matches(Caketime, Cake): " << boggle.matches("Caketime", "cake") << std::endl;

   return 0;
}
