#include"boggleutil.h"
#include <vector>
#include <string>
#include <stdlib.h>
#include <iostream>

//In this file, implement all of the operations your data structures support (you have declared these operations in boggleutil.h).
RadNode::RadNode(int size, std::string data)
{
   radix = size;
   key = data;
   children.resize(radix);
   endFlag = false;
}


RadNode::RadNode(int size, std::string data, bool end)
{
   radix = size;
   key = data;
   children.resize(radix);
   endFlag = end;
}

RadNode::~RadNode()
{
}

int RadNode::getRadix()
{
  return radix;
}

void RadNode::setChild(int child, RadNode*& data)
{
   if(child < radix)
   {
      children[child] = data; 
   }
}


std::string RadNode::getKey()
{
   return key;
}

RadNode* RadNode::getChild(int child)
{
   if(child >= radix)
   {
      return nullptr; 
   }
   else
   {
      return children[child];
   }
}

std::vector<RadNode*> RadNode::getChildren()
{
   return children;
}

bool RadNode::getEnd()
{
   return endFlag;
}

void RadNode::setEnd(bool end)
{
   endFlag = end;
}

LexTree::LexTree()
{
   root = nullptr;
}

/**LexTree::LexTree(RadNode First)
{
   //root = &First;
}**/

LexTree::LexTree(std::string First)
{
   root = nullptr;
   addWord(First);
}

LexTree::~LexTree()
{
  destroyNode(this->root); 
}

void destroyNode(RadNode*& node)
{
   if(node != nullptr)
   {
      int size = node->getRadix();
      std::vector<RadNode*> children = node->getChildren();   

      for(int i = 0; i < size; i++)
      { 
        if(children[i] != nullptr)
        {
           destroyNode(children[i]);
        }
      } 
      delete node;
   }
}

void LexTree::addChild(int child_p, char child, RadNode*& parent)
{
   std::string input;
   input.append(1, child);
   RadNode* node = new RadNode(3, input);
   parent->setChild(child_p, node);
}

RadNode* LexTree::getRoot()
{
   return root;
}

void LexTree::addChildwEnd(int child_p, char child, RadNode*& parent, bool End)
{
   std::string input;
   input.append(1, child);
   RadNode* node = new RadNode(3, input, true);
   parent->setChild(child_p, node);
}

void LexTree::addWord(std::string word)
{
   if(root == nullptr && word.size() != 0)
   {
      root = new RadNode(3, word.substr(0, 1));
   }
   else if(word.size() == 0)
   {
      return;
   }

   RadNode* curr = root;

   for(int i = 0; i < (word.size() - 1); i++)
   {
      word[i] = std::toupper(word[i]);
      std::cout << "word[" << i << "]: " << word[i] << std::endl; 

      int comparison;
      comparison = curr->getKey().compare(word.substr(i,1));

      while(comparison)
      {
         std::cout << "Comparison: " << comparison << std::endl;

         if(comparison < 0)
         { 
            if(curr->getChild(0) != nullptr)
            {
               curr = curr->getChild(0);
               std::cout << "Current Node: " << curr->getKey() << std::endl;
            }
            else
            { 
               addChild(0, word[i], curr);
               curr = curr->getChild(0);
               std::cout << "Current Node: " << curr->getKey() << std::endl;
            }
         }
         else if(comparison > 0)
         {
            if(curr->getChild(2) != nullptr)
            {
               curr = curr->getChild(2);
               std::cout << "Current Node: " << curr->getKey() << std::endl;
            }
            else
            { 
               addChild(2, word[i], curr);
               curr = curr->getChild(2);
               std::cout << "Current Node: " << curr->getKey() << std::endl;
            }
         }

         comparison = curr->getKey().compare(word.substr(i,1));
         std::cout << "Iteration of While Loop" << std::endl;
      }
      std::cout << "End of While Loop" << std::endl;

      if(i == word.size()-2)
      {
         break;
      }

      //Goto Next next level 
      //If there is no level
      if(curr->getChild(1) == nullptr)
      {
         addChild(1, std::toupper(word[i+1]), curr);
         curr = curr->getChild(1);
         std::cout << "Current Node: " << curr->getKey() << std::endl;
      }
      //otherwise traverse
      else
      {
         curr = curr->getChild(1); 
         std::cout << "Current Node: " << curr->getKey() << std::endl;
      }
   }

   if(curr->getChild(1) == nullptr)
   {
      addChildwEnd(1, std::toupper(word[word.size()-1]), curr, true); 
      curr = curr->getChild(1);
      std::cout << "Current Node: " << curr->getKey() << std::endl;
   }
   else
   {
      curr = curr->getChild(1);
      curr->setEnd(true);
      std::cout << "Current Node: " << curr->getKey() << std::endl;
   }
}

std::vector<RadNode*> LexTree::BFS()
{
   std::vector<RadNode*> output_queue;
   std::vector<RadNode*> queue;
   queue.push_back(root);

   while(queue.size() > 0)
   {
      RadNode* front = queue.front();
      queue.erase(queue.begin());

      output_queue.push_back(front);

      std::vector<RadNode*> children = front->getChildren();
      for(int i = 0; i < front->getRadix(); i++)
      {
         if(children[i] != nullptr)
            queue.push_back(children[i]);   
      }

   } 
 
   return output_queue;
}

bool LexTree::Search(std::string word)
{
   RadNode* curr = root;
   int comparison;
   comparison = curr->getKey().compare(word.substr(0,1));

   std::cout << "Current Node: " << curr->getKey() << std::endl;
   for(int i = 0; i < word.size() - 1; i++)
   {
      word[i] = std::toupper(word[i]);

      while(comparison)
      {
         std::cout << "Comparison: " << comparison << std::endl;

         if(comparison < 0)
         { 
            if(curr->getChild(0) != nullptr)
            {
               curr = curr->getChild(0);
               std::cout << "Current Node: " << curr->getKey() << std::endl;
            }
            else
            {
               return false; 
            }
         }
         else if(comparison > 0)
         {
            if(curr->getChild(2) != nullptr)
            {
               curr = curr->getChild(2);
               std::cout << "Current Node: " << curr->getKey() << std::endl;
            }
            else
            {
               return false; 
            }
         }

         comparison = curr->getKey().compare(word.substr(i,1));
         std::cout << "Iteration of While Loop" << std::endl;
      }

      if(curr->getChild(1) == nullptr)
      {
         return false;
      } 
      else
      {
         curr = curr->getChild(1);
         std::cout << "Current Node: " << curr->getKey() << std::endl;
      }
   }

   if(curr->getEnd() == true)
   {
      std::cout << "Final Node: " << curr->getKey() << std::endl;
      return true;
   }
   else
   {
      std::cout << "Final Node: " << curr->getKey() << std::endl;
      return false;
   }
   
}

Board::Board()
{
   board = nullptr;
   col = 0;
   row = 0;
   
   /**visited = new bool*[row]; 
   for(int i = 0; i < row; i++)
   {
      visited[i] = new bool[col];
   }**/
}


Board::Board(std::string** board, int row, int col)
{
   this->board = board;
   this->col = col;
   this->row = row;

   /**visited = new bool*[row]; 
   for(int i = 0; i < row; i++)
   {
      visited[i] = new bool[col];
   }**/
}

Board::~Board()
{
   for(int i = 0; i < row; i++)
   {
      delete [] board[i];
   }
}

std::vector<int> Board::getNeighbors(int pos, std::vector<bool> visited)
{
   std::vector<int> neigh;  

    int _row = pos/col;
    int _col = pos%col; 

   //std::cout << "1st Conditional" << std::endl;
   if(!tooHigh(_row + 1, _col) && !visited[pos + col]) 
   {
      neigh.push_back((((_row + 1) * col) + _col));
   }
   //std::cout << "2nd Conditional" << std::endl;
   if(!tooHigh(_row + 1, _col + 1) && !tooRight(_row + 1, _col + 1) && !visited[pos + col + 1]) 
   {
      neigh.push_back((((_row + 1) * col) + (_col + 1)));
   }
   //std::cout << "3rd Conditional" << std::endl;
   if(!tooHigh(_row + 1, _col - 1) && !tooLeft(_row + 1, _col - 1) && !visited[pos + col - 1]) 
   {
      neigh.push_back((((_row + 1) * col) + (_col - 1)));
   }
   //std::cout << "4th Conditional" << std::endl;
   if(!tooRight(_row, _col + 1) && !visited[pos + 1]) 
   {
      neigh.push_back(((_row * col) + (_col + 1)));
   }
   //std::cout << "5th Conditional" << std::endl;
   if(!tooLeft(_row, _col - 1) && !visited[pos - 1]) 
   {
      neigh.push_back(((_row * col) + (_col - 1)));
   }
   //std::cout << "6th Conditional" << std::endl;
   if(!tooLow(_row - 1, _col) && !visited[pos - col]) 
   {
      neigh.push_back((((_row - 1) * col) + _col));
   }
   //std::cout << "7th Conditional" << std::endl;
   if(!tooLow(_row - 1, _col + 1) && !tooRight(_row - 1, _col + 1) && !visited[pos - col + 1]) 
   {
      neigh.push_back((((_row - 1) * col) + (_col + 1)));
   }
   //std::cout << "8th Conditional" << std::endl;
   if(!tooLow(_row - 1, _col - 1) && !tooLeft(_row - 1, _col - 1) && !visited[pos - col - 1]) 
   {
      neigh.push_back((((_row - 1) * col) + (_col - 1)));
   }

   return neigh; 
}

std::vector<int> Board::contains(std::string word)
{
   std::vector<int> queue;   
   std::vector<int> output_queue;

   for(int i = 0; i < row; i++)
   {
      for(int j = 0; j < col; j++)
      {
         if(!board[i][j].compare(word.substr(0, board[i][j].size()))) 
         {
         }     
      }
   }
   return output_queue;  
}

std::vector<int> Board::Check(std::string word, std::string path, int pos, std::vector<bool> visited, std::vector<int> pathway)
{
  if(word.compare(path))
  {
     std::cout << "If" << std::cout;
     return pathway;
  } 
  else
  {
     std::cout << "Else" << std::cout;
     std::vector<int> children = getNeighbors(pos, visited);
    
     /**for(int i = 0; i < children.size(); i++)
     { 
        std::cout << (children[i]%4) << ", " << (children[i]/4) << std::endl;
     }**/ 
     
     for(int i = 0; i < children.size(); i++)
     {
        std::string met = path;
        met += board[children[i]/col][children[i]%col];

        if(matches(word, met))
        {
            std::vector<bool> recur_visited = visited;
            std::vector<int> temp_path = pathway;
            recur_visited[children[i]] = 1;
            temp_path.push_back(children[i]);
            std::vector<int> passage = Check(word, met, children[i], recur_visited, temp_path);
            if(!passage.empty())
            {
               return passage;
            } 
        }
        else
        {
           std::vector<int> empty;
           return empty;
        }
     }

     std::vector<int> empty;
     return empty;

  }
}

bool Board::matches(std::string word, std::string path)
{
   std::cout << word.substr(0, path.size()) << std::endl;
   return !path.compare(word.substr(0,path.size()));
}

/**Die::Die(std::string dat, int posn, std::vector neighb)
{
  data = dat;
  pos = posn;
  neigh = neighb;
}

std::string Die::getData()
{
   return data;
}

int Die::getPos()
{
  return pos;
}
std::vector<int> Die::getNeigh()
{
   return neighbors;
}**/
