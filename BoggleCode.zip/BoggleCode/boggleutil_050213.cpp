#include"boggleutil.h"
#include <vector>
#include <string>
#include <stdlib.h>
#include <iostream>

//In this file, implement all of the operations your data structures support (you have declared these operations in boggleutil.h).
RadNode::RadNode(int size, std::string data)
{
   radix = size;
   key = data;
   children.resize(radix);
   endFlag = false;
}


RadNode::RadNode(int size, std::string data, bool end)
{
   radix = size;
   key = data;
   children.resize(radix);
   endFlag = end;
}

RadNode::~RadNode()
{
  /**std::cout << "Node Contents: " << key << std::endl;
  std::cout << "Node Size: " << radix << std::endl;
  for(int i = 0; i < radix; i++)
  {
     std::cout << "Child" << i << "Freed" << std::endl;
     if(children[i] != nullptr)
     {
        delete children[i];
     }
  }**/
}

int RadNode::getRadix()
{
  return radix;
}

void RadNode::setChild(int child, RadNode*& data)
{
   if(child < radix)
   {
      children[child] = data; 
   }
}


std::string RadNode::getKey()
{
   return key;
}

RadNode* RadNode::getChild(int child)
{
   if(child >= radix)
   {
      return nullptr; 
   }
   else
   {
      return children[child];
   }
}

std::vector<RadNode*> RadNode::getChildren()
{
   return children;
}

bool RadNode::getEnd()
{
   return endFlag;
}

void RadNode::setEnd(bool end)
{
   endFlag = end;
}

LexTree::LexTree()
{
   root = new RadNode(26, " ");
}

/**LexTree::LexTree(RadNode First)
{
   root = &First;
}**/

LexTree::LexTree(std::string First)
{
   root = new RadNode(26, " ");
   //addWord(First);
}

LexTree::~LexTree()
{
  destroyNode(root); 
}

void destroyNode(RadNode*& node)
{
   int size = node->getRadix();
   std::vector<RadNode*> children = node->getChildren();   

   for(int i = 0; i < size; i++)
   { 
     if(children[i] != nullptr)
     {
        destroyNode(children[i]);
     }
   } 
   delete node;
}

void LexTree::addChild(char child, RadNode*& parent)
{
   std::string input;
   input.append(1, child);
   RadNode* node = new RadNode(26, input);
   parent->setChild(genHash(child), node);
}

RadNode* LexTree::getRoot()
{
   return root;
}

void LexTree::addChildwEnd(char child, RadNode*& parent, bool End)
{
   std::string input;
   input.append(1, child);
   RadNode* node = new RadNode(26, input, true);
   parent->setChild(genHash(child), node);
}

void LexTree::addWord(std::string word)
{
   RadNode* curr = root;

   int index;
   for(int i = 0; i < (word.size() - 1); i++)
   {
      index = genHash(word[i]);
      std::cout << "Implanting word[" << i << "]: " << word[i] << std::endl; 
      if(curr->getChild(index) == nullptr)
      {
         std::cout << "Entered Conditional" << std::endl;
         addChild(word[i], curr);
      }
      std::cout << "Current Node: " << curr->getKey() << std::endl;
      curr = curr->getChild(index);
   }
   std::cout << "Implanting word[" << word.size()-1 << "]: " << word[word.size()-1] << std::endl; 
   std::cout << "Current Node: " << curr->getKey() << std::endl;
   index = genHash(word[word.size()-1]);
   RadNode* final = curr->getChild(index);
   if(final == nullptr)
   {
      std::cout << "Entered Conditional" << std::endl;
      addChildwEnd(word[word.size()-1], curr, true);
   }
   else
      final->setEnd(true);
}

std::vector<RadNode*> LexTree::BFS()
{
   std::vector<RadNode*> output_queue;
   std::vector<RadNode*> queue;
   queue.push_back(root);

   while(queue.size() > 0)
   {
      RadNode* front = queue.front();
      queue.erase(queue.begin());

      output_queue.push_back(front);

      std::vector<RadNode*> children = front->getChildren();
      for(int i = 0; i < front->getRadix(); i++)
      {
         if(children[i] != nullptr)
            queue.push_back(children[i]);   
      }
   } 
 
   return output_queue;
}

bool LexTree::Search(std::string word)
{
   RadNode* curr = root;

   for(int i = 0; i < word.size(); i++)
   {
      curr = curr->getChild(genHash(word[i]));
      if(curr == nullptr)
         return false;
   }
   if(curr->getEnd() == true)
      return true;
   else
      return false;
   
}

int genHash(char child)
{
   switch(child)
   {
      case 'A':
         return 0; 
         break;
      case 'B':
         return 1; 
         break;
      case 'C':
         return 2; 
         break;
      case 'D':
         return 3; 
         break;
      case 'E':
         return 4; 
         break;
      case 'F':
         return 5; 
         break;
      case 'G':
         return 6; 
         break;
      case 'H':
         return 7; 
         break;
      case 'I':
         return 8; 
         break;
      case 'J':
         return 9; 
         break;
      case 'K':
         return 10; 
         break;
      case 'L':
         return 11; 
         break;
      case 'M':
         return 12; 
         break;
      case 'N':
         return 13; 
         break;
      case 'O':
         return 14; 
         break;
      case 'P':
         return 15; 
         break;
      case 'Q':
         return 16; 
         break;
      case 'R':
         return 17; 
         break;
      case 'S':
         return 18; 
         break;
      case 'T':
         return 19; 
         break;
      case 'U':
         return 20; 
         break;
      case 'V':
         return 21; 
         break;
      case 'W':
         return 22; 
         break;
      case 'X':
         return 23; 
         break;
      case 'Y':
         return 24; 
         break;
      case 'Z':
         return 25; 
         break;
      case 'a':
         return 0; 
         break;
      case 'b':
         return 1; 
         break;
      case 'c':
         return 2; 
         break;
      case 'd':
         return 3; 
         break;
      case 'e':
         return 4; 
         break;
      case 'f':
         return 5; 
         break;
      case 'g':
         return 6; 
         break;
      case 'h':
         return 7; 
         break;
      case 'i':
         return 8; 
         break;
      case 'j':
         return 9; 
         break;
      case 'k':
         return 10; 
         break;
      case 'l':
         return 11; 
         break;
      case 'm':
         return 12; 
         break;
      case 'n':
         return 13; 
         break;
      case 'o':
         return 14; 
         break;
      case 'p':
         return 15; 
         break;
      case 'q':
         return 16; 
         break;
      case 'r':
         return 17; 
         break;
      case 's':
         return 18; 
         break;
      case 't':
         return 19; 
         break;
      case 'u':
         return 20; 
         break;
      case 'v':
         return 21; 
         break;
      case 'w':
         return 22; 
         break;
      case 'x':
         return 23; 
         break;
      case 'y':
         return 24; 
         break;
      case 'z':
         return 25; 
         break;
      default:
         return 26;
         break;
   }
}

Board::Board()
{
   board = nullptr;
   col = 0;
   row = 0;
   
   /**visited = new bool*[row]; 
   for(int i = 0; i < row; i++)
   {
      visited[i] = new bool[col];
   }**/
}


Board::Board(std::string** board, int row, int col)
{
   this->board = board;
   this->col = col;
   this->row = row;

   /**visited = new bool*[row]; 
   for(int i = 0; i < row; i++)
   {
      visited[i] = new bool[col];
   }**/
}

Board::~Board()
{
   for(int i = 0; i < row; i++)
   {
      delete [] board[i];
   }
}

std::vector<int> Board::checkNeighbors(std::string word, int _row, int _col)
{
   std::string comp(board[row][col]);
   std::vector<std::string> queue_s;
   std::vector<int> queue_i;
   std::vector<int> queue_output;
 
   bool visit[row][col];
 
   queue_s.push_back(word.substr(board[i][j].size()-1));
   queue_output.push_back(_row);
   queue_output.push_back(_col);
   queue_i.push_back(_row);
   queue_i.push_back(_col);

   while(!queue_s.empty())
   {
      int pos_x = queue_i.top();
      //queue_i.
      if(tooHigh(_row + 1, _col))
      {
      
      }
      else
      {
      }
   }
}

/**void Board::append_neighbors(bool[][] visited, std::vector<int>*& , int _row, int _col)
{
   bool top = 0;
   bool bot = 0;
   bool left = 0;
   bool right = 0;

   //(_row + 1 >= row)? (top = 1):

   queue_i.push_back(row+1);
   queue_i.push_back(col);
   queue_i.push_back(row+1);
   queue_i.push_back(col+1);
   queue_i.push_back(row+1);
   queue_i.push_back(col);
}**/
/**std::vector<int> Board::contains(std::string word)
{
   std::vector<int> queue;   
   std::vector<int> output_queue;

   for(int i = 0; i < row; i++)
   {
      for(int j = 0; j < col; j++)
      {
         //visited[i][j] = 1;
         if(!board[i][j].compare(word.substr(board[i][j].size()-1))) 
         {
         }     
      }
   }
   return output_queue;  
}**/
