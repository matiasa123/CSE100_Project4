#include "boggleutil.h"
#include <stdlib.h>
#include <iostream>
#include <string>

int main()
{
   /**std::string string1 = "e";
   std::string string2 = "fg";
   std::string string3;
   string3.append(1, 'h');
   //std::string string3 = 'h'; //Invalid Syntax
   RadNode rad1(4, "a");
   //RadNode radc1(4, 'b'); //Invalid Syntax
   RadNode radc2(4, "cd");
   RadNode radc3(4, string1);
   RadNode radc4(4, string2); 
   RadNode radc5(4, string3, true); 
   //RadNode radc5(4, string3); //Invalid by string3 invalidity

   std::cout << "Rad1 String:" << rad1.getKey() << std::endl;
   //std::cout << "Radc1 String:" << radc1.getKey() << std::endl;
   std::cout << "Radc2 String:" << radc2.getKey() << " End: " << radc2.getEnd() << std::endl;
   std::cout << "Radc3 String:" << radc3.getKey() << " End: " << radc3.getEnd() << std::endl;
   std::cout << "Radc4 String:" << radc4.getKey() << " End: " << radc4.getEnd() << std::endl;
   std::cout << "Radc5 String:" << radc5.getKey() << " End: " << radc5.getEnd() << std::endl;
   //std::cout << "Radc5 String:" << radc5.getKey() << std::endl; //Invalid
   
   rad1.setChild(0, radc2);
   rad1.setChild(1, radc3);
   rad1.setChild(2, radc4);
   rad1.setChild(3, radc5);

   radc2.setEnd(true);
  
   std::vector<RadNode*> vector_pointer;
   vector_pointer = rad1.getChildren();

   std::cout << "Rad1 Child (Radc2): " << rad1.getChild(0)->getKey() << " End: " << rad1.getChild(0)->getEnd() << std::endl;
   std::cout << "Rad1 Child (Radc3): " << rad1.getChild(1)->getKey() << " End: " << rad1.getChild(1)->getEnd() << std::endl;
   std::cout << "Rad1 Child (Radc4): " << rad1.getChild(2)->getKey() << " End: " << rad1.getChild(2)->getEnd() << std::endl;
   std::cout << "Rad1 Child (Radc5): " << rad1.getChild(3)->getKey() << " End: " << rad1.getChild(3)->getEnd() << std::endl;
   std::cout << "Children from get Children: " << std::endl;
   std::cout << "Rad1 Child (Radc2): " << vector_pointer[0]->getKey() << " End: " << vector_pointer[0]->getEnd() << std::endl;
   std::cout << "Rad1 Child (Radc3): " << vector_pointer[1]->getKey() << " End: " << vector_pointer[1]->getEnd() << std::endl;
   std::cout << "Rad1 Child (Radc4): " << vector_pointer[2]->getKey() << " End: " << vector_pointer[2]->getEnd() << std::endl;
   std::cout << "Rad1 Child (Radc5): " << vector_pointer[3]->getKey() << " End: " << vector_pointer[3]->getEnd() << std::endl;

   std::cout << "Setting Child 1 to EndFlag" << std::endl;
   rad1.getChild(0)->setEnd(true);
   
   std::cout << "Radc2 String:" << radc2.getKey() << " End: " << radc2.getEnd() << std::endl;
   std::cout << "Rad1 Child (Radc2): " << rad1.getChild(0)->getKey() << " End: " << rad1.getChild(0)->getEnd() << std::endl;
   std::cout << "Rad1 Child (Radc2): " << vector_pointer[0]->getKey() << " End: " << vector_pointer[0]->getEnd() << std::endl;


   LexTree tree;
   RadNode* node = tree.getRoot();
   tree.addChild('a', node);

   RadNode* node1= new RadNode(26, "a");
   RadNode* node2= new RadNode(26, "b");
   node1->setChild(genHash('b'), node2);
 
   std::cout << "root: " << node1->getKey() << std::endl; 
   std::cout << "root child: " << node1->getChild(1)->getKey() << std::endl; 

   destroyNode(node1);**/

   LexTree tree;
  
   /**tree.addWord("Aran");
   tree.addWord("Are");
   tree.addWord("Caketime");

   std::cout << "Search for Aran: " << tree.Search("Aran") << std::endl;
   std::cout << "Search for are: " << tree.Search("are") << std::endl;
   std::cout << "Search for CAketime: " << tree.Search("Caketime") << std::endl;
   std::cout << "Search for le: " << tree.Search("le") << std::endl;
   std::cout << "Search for cake: " << tree.Search("cake") << std::endl;
   std::cout << "Search for AranCakeTime: " << tree.Search("AranCaketime") << std::endl;**/
 
   tree.addChild('a', tree.root);
   tree.addChild('b', tree.root);
   tree.addChild('x', tree.root);
   tree.addChild('Y', tree.root);
   tree.addChild('r', tree.root);
   
   RadNode* root = tree.getRoot();
   RadNode* child = root->getChild(0);
   tree.addChild('b', child);
   tree.addChild('c', child);
   tree.addChild('d', child);
   tree.addChild('t', child);
   tree.addChild('Y', child);

   std::vector<RadNode*> output = tree.BFS();
 
   std::cout << "Breadth First Search Traversal: " << std::endl; 
   for(int i = 0; i < output.size(); i++)
   {
      std::cout << output[i]->getKey() << " " << output[i]->getEnd() << std::endl;
   }

   std::cout << "root: " << root->getKey() << std::endl;
   std::cout << "child: " << root->getChild(0)->getKey() << std::endl;
   std::cout << "child: " << root->getChild(0)->getChild(1)->getKey() << std::endl;
   for(int i = 0; i < ; i++)
   { 
      std::cout << "child" << i <<": " << tree.root->getChild(i) << std::endl; 
   }
   for(int i = 0; i < 26; i++)
   { 
      std::cout << "child" << i <<": " << tree.root->getChild(0)->getChild(i) << std::endl; 
   }
  
   /**std::string** board_rep;
   board_rep = new std::string*[4];
   for(int i = 0; i < 4; i++)
      board_rep[i] = new std::string[4];

   board_rep[0][0] = std::string("a");
   board_rep[0][1] = std::string("b");
   board_rep[0][2] = std::string("c");
   board_rep[0][3] = std::string("d");
   board_rep[1][0] = std::string("e");
   board_rep[1][1] = std::string("f");
   board_rep[1][2] = std::string("g");
   board_rep[1][3] = std::string("h");
   board_rep[2][0] = std::string("i");
   board_rep[2][1] = std::string("j");
   board_rep[2][2] = std::string("k");
   board_rep[2][3] = std::string("l");
   board_rep[3][0] = std::string("m");
   board_rep[3][1] = std::string("n");
   board_rep[3][2] = std::string("o");
   board_rep[3][3] = std::string("p");**/
 
   /**for(int i = 0; i < 4; i++)
   {
      for(int j = 0; j < 4; j++)
      {
         board_rep[i][j] = std::string("a");
      }
   }**/

   /**board_rep[0] = {std::string("a"), std::string("b"), std::string("c"), std::string("d")};
   board_rep[1] = {std::string("e"), std::string("f"), std::string("g"), std::string("h")};
   board_rep[2] = {std::string("i"), std::string("j"), std::string("k"), std::string("l")};
   board_rep[3] = {std::string("m"), std::string("n"), std::string("o"), std::string("p")};**/
 
   /**Board board(board_rep, 4, 4);
 
   //bool** visited = board.getVisited();
   //std::string** boggle_board = board.getBoard();

   //board.contains("a");


   std::cout << "Too High Test" << std::endl;
   for(int i = 4; i >= -1; i--)
   {
      for(int j = 4; j >= -1; j--)
      {
         std::cout << board.tooHigh(i, j) << " ";
         //std::cout << boggle_board[i][j] << std::endl; 
      }
      std::cout << std::endl;
   }
 
   std::cout << "Too Low Test" << std::endl;
   for(int i = 4; i >= -1; i--)
   {
      for(int j = 4; j >= -1; j--)
      {
         std::cout << board.tooLow(i, j) << " ";
         //std::cout << boggle_board[i][j] << std::endl; 
      }
      std::cout << std::endl;
   }

   std::cout << "Too Left Test" << std::endl;
   for(int i = 4; i >= -1; i--)
   {
      for(int j = 4; j >= -1; j--)
      {
         std::cout << board.tooLeft(i, j) << " ";
         //std::cout << boggle_board[i][j] << std::endl; 
      }
      std::cout << std::endl;
   }


   std::cout << "Too Right Test" << std::endl;
   for(int i = 4; i >= -1; i--)
   {
      for(int j = 4; j >= -1; j--)
      {
         std::cout << board.tooRight(i, j) << " ";
         //std::cout << boggle_board[i][j] << std::endl; 
      }
      std::cout << std::endl;
   }**/

   return 0;
}
